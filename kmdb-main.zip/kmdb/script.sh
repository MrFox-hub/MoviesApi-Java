#!/bin/bash

# Add all changes to git
git add .

# Commit the changes with the message "test"
git commit -m "test"

# Push the changes to the remote repository
git push
